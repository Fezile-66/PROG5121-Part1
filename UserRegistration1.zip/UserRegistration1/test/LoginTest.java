/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import userregistration1.Login;



public class LoginTest {

//    // Create an instance of your Login class to test it
    Login login = new Login();

    // --- Test Username ---
    @Test
    public void testUsernameCorrectlyFormatted() {
        // Test Data: "kyl_1" should return True
        assertTrue(login.checkUserName("kyl_1"), "Username should be valid");
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
        // Test Data: "kyle!!!!!!!" should return False
        assertFalse(login.checkUserName("kyle!!!!!!!"), "Username should be invalid");
    }

    // --- Test Password ---
    @Test
    public void testPasswordMeetsComplexity() {
        // Test Data: "Ch&&sec@ke99!" should return True
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"), "Password should be valid");
    }

    @Test
    public void testPasswordDoesNotMeetComplexity() {
        // Test Data: "password" should return False
        assertFalse(login.checkPasswordComplexity("password"), "Password should be invalid");
    }

    // --- Test Cell Phone ---
    @Test
    public void testCellPhoneCorrectlyFormatted() {
        // Test Data: "+27838968976" should return True
        assertTrue(login.checkCellPhoneNumber("+27838968976"), "Cell phone should be valid");
    }

    @Test
    public void testCellPhoneIncorrectlyFormatted() {
        // Test Data: "08966553" should return False
        assertFalse(login.checkCellPhoneNumber("08966553"), "Cell phone should be invalid");
    }

    // Test Login Logic
    @Test
    public void testLoginSuccessful() {
        // First register the user so they exist in the system
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        
        // Now try to login with the same details
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"), "Login should be successful");
    }

    @Test
    public void testLoginFailed() {
        // First register the user
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        
        // Try to login with Wrong details
        assertFalse(login.loginUser("kyl_1", "WrongPassword123!"), "Login should fail");
    }
    
    // Test registration messages (AssertEquals)
    @Test
    public void testRegisterUserSuccessMessage() {
        String expected = "User successfully registered.";
        String actual = login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertEquals(expected, actual);
    }
}