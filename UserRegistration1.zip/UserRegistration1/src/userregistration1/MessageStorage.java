/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package userregistration1;

import java.io.*;
import java.util.*;

public class MessageStorage {

    // Parallel arrays (Step 1 requirement)
    public static ArrayList<String> sentMessages = new ArrayList<>();
    public static ArrayList<String> disregardedMessages = new ArrayList<>();
    public static ArrayList<String> storedMessages = new ArrayList<>();
    public static ArrayList<String> messageHashes = new ArrayList<>();
    public static ArrayList<String> messageIDs = new ArrayList<>();
    public static ArrayList<String> recipients = new ArrayList<>(); // needed for display/report

    // Test data message 1-5 (per assignment)
    public static void loadTestData() {
        addMessage("+27834557896", "Did you get the cake?", "Sent", "0012345678", "00:0:DIDCAKE");
        addMessage("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored", "0022345678", "00:1:WHEREON");
        addMessage("+27834484567", "Yohoooo, I am at your gate.", "Disregard", "0032345678", "00:2:YOHOOOGATE");
        addMessage("0838884567", "It is dinner time !", "Sent", "0838884567", "08:3:IT!TIME");
        addMessage("+27838884567", "Ok, I am leaving without you.", "Stored", "0052345678", "00:4:OKYOU");
    }

    private static void addMessage(String recip, String msg, String flag,
                                   String id, String hash) {
        if (flag.equals("Sent")) sentMessages.add(msg);
        else if (flag.equals("Disregard")) disregardedMessages.add(msg);
        else if (flag.equals("Stored")) storedMessages.add(msg);
        messageHashes.add(hash);
        messageIDs.add(id);
        recipients.add(recip);
    }

    // ---- Read JSON file into storedMessages array ----
    public static void loadStoredFromJson(String filePath) {
        storedMessages.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
          
            String content = sb.toString();
            int idx = 0;
            while ((idx = content.indexOf("\"message\":", idx)) != -1) {
                int start = content.indexOf('"', idx + 10) + 1;
                int end = content.indexOf('"', start);
                if (start > 0 && end > start)
                    storedMessages.add(content.substring(start, end));
                idx = end;
            }
            System.out.println("Loaded " + storedMessages.size() + " stored messages from JSON.");
        } catch (IOException e) {
            System.out.println("No JSON file found yet. Run Option 1 to store messages first.");
        }
    }

    // ---- Feature (a): Display sender and recipient of all stored ----
    public static String displayStoredRecipients() {
        if (storedMessages.isEmpty()) return "No stored messages.";
        StringBuilder sb = new StringBuilder("Stored Messages — Recipients:\n");
        for (String r : recipients) sb.append("Recipient: ").append(r).append("\n");
        return sb.toString();
    }

    // ---- Feature (b): Longest stored message ----
    public static String longestStoredMessage() {
        String longest = "";
        for (String s : storedMessages)
            if (s.length() > longest.length()) longest = s;
        return longest.isEmpty() ? "No stored messages." : longest;
    }

    // ---- Feature (c): Search by message ID ----
    public static String searchByMessageID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                return "Recipient: " + recipients.get(i) + "\nMessage: " +
                       (i < storedMessages.size() ? storedMessages.get(i) : "[other flag]");
            }
        }
        return "Message ID not found.";
    }

    // ---- Feature (d): All messages for a recipient ----
    public static List<String> searchByRecipient(String recipient) {
        List<String> found = new ArrayList<>();
        for (int i = 0; i < recipients.size(); i++)
            if (recipients.get(i).equals(recipient))
                found.add(i < storedMessages.size() ? storedMessages.get(i) : "[sent/disregarded]");
        return found;
    }

    // ---- Feature (e): Delete by message hash ----
    public static String deleteByHash(String hash) {
        int idx = messageHashes.indexOf(hash);
        if (idx == -1) return "Hash not found.";
        String deleted = idx < storedMessages.size() ? storedMessages.get(idx) : "[other]";
        if (idx < storedMessages.size()) storedMessages.remove(idx);
        if (idx < messageHashes.size()) messageHashes.remove(idx);
        if (idx < messageIDs.size()) messageIDs.remove(idx);
        if (idx < recipients.size()) recipients.remove(idx);
        return "Message: \"" + deleted + "\" successfully deleted.";
    }

    // ---- Feature (f): Full report ----
    public static String displayReport() {
        StringBuilder sb = new StringBuilder("=== STORED MESSAGES REPORT ===\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            sb.append("Hash: ").append(i < messageHashes.size() ? messageHashes.get(i) : "N/A")
              .append("\nRecipient: ").append(i < recipients.size() ? recipients.get(i) : "N/A")
              .append("\nMessage: ").append(storedMessages.get(i)).append("\n---\n");
        }
        return sb.toString();
    }
}
