/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package userregistration1;

import java.util.Scanner;

public class UserRegistration1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login loginSystem = new Login();

        System.out.println("                                 ");
        System.out.println("               REGISTRATION PAGE          ");
        System.out.println("                                 ");
        
        // Registration page input
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter Username (must contain '_' and be less or eqaul to 5 characters): ");
        String username = scanner.nextLine();

        System.out.print("Enter Password (8+ characters, Capital, Number, Special): ");
        String password = scanner.nextLine();

        System.out.print("Enter SA Cell Phone (e.g., +27838968976): ");
        String cellNumber = scanner.nextLine();

        // Registration process
        String registrationMessage = loginSystem.registerUser(username, password, cellNumber, firstName, lastName);
        System.out.println("\nRegistration Status: " + registrationMessage);

        // Only proceed to login if registration was successful
        if (registrationMessage.equals("User successfully registered.")) {
            
            System.out.println("                                         ");
            System.out.println("                    LOGIN PAGE                     ");
            System.out.println("                                         ");
            
            // Login page input
            System.out.print("Enter Username to Login: ");
            String loginUser = scanner.nextLine();

            System.out.print("Enter Password to Login: ");
            String loginPass = scanner.nextLine();

            // Process login
            boolean isAuthenticated = loginSystem.loginUser(loginUser, loginPass);
            String loginMessage = loginSystem.returnLoginStatus(isAuthenticated);
            
            System.out.println("\nLogin Status: " + loginMessage);
        } else {
            System.out.println("\nPlease fix the errors above and try registering again.");
        }

        scanner.close();
    }
}
